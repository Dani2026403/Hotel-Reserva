HOTEL LUXURY PRO - PROYECTO ORGANIZADO

Esta versión es una página más completa y profesional de reservas hoteleras.

CÓMO ABRIR
1. Descomprime el ZIP.
2. Entra a la carpeta "hotel_luxury_pro".
3. Abre "index.html" con doble clic.
4. La página queda lista en el navegador.

ESTRUCTURA
hotel_luxury_pro/
├── index.html
├── assets/
│   ├── css/
│   │   └── styles.css
│   ├── js/
│   │   └── app.js
│   └── img/
│       └── hotel-luxury-pro-placeholder.svg
└── README.txt

FUNCIONES INCLUIDAS
- Registro de usuario.
- Inicio y cierre de sesión.
- Perfil editable.
- Habitaciones con filtros avanzados.
- Favoritos por usuario.
- Detalle de cada habitación.
- Reserva con fechas, huéspedes, método de pago y servicios extra.
- Cálculo de subtotal, extras, impuestos y total.
- Mis reservas.
- Cancelación de reservas.
- Exportar reservas en JSON.
- Ofertas comerciales.
- Formulario de contacto.
- Diseño responsive para celular, tablet y escritorio.

IMPORTANTE
- No necesita Flask.
- No necesita Python.
- No necesita instalar paquetes.
- Los datos se guardan en localStorage del navegador.
- Es una simulación frontend, ideal para presentar visualmente el proyecto.
- Si borras los datos del navegador, se borran usuarios, favoritos y reservas.
